import img1 from "../../../image/a1.jpg";
import img2 from "../../../image/a2.jpg";
import img3 from "../../../image/a3.jpg";
import img4 from "../../../image/a4.jpg";
import img5 from "../../../image/a5.jpg";
const product_card=[
    {
        id:"1",
        img:img1,
        title:"Empty",
        offerPrice:500,
        currency:"Rs.",
        rating:5,
        label:"new",
        url:"#"
    },
    {
        id:"2",
        img:img2,
        title:"Empty",
        offerPrice:750,
        currency:"Rs.",
        rating:4,
        url:"#"
    },
    {
        id:"3",
        img:img3,
        title:"Empty",
        offerPrice:300,
        currency:"$",
        rating:5,
        label:'scale',
        url:"#"
    },
    {
        id:"4",
        img:img4,
        title:"Empty",
        offerPrice:350,
        currency:"Rs.",
        rating:4,
        url:"#"
    },
    {
        id:"5",
        img:img5,
        title:"Empty",
        offerPrice:550,
        currency:"$",
        rating:4,
        url:"#"
    },
]

export default product_card;