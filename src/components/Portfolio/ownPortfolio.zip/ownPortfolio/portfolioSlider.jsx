import React from 'react'
import "./card.scss";
import Card from "./card";

function PortfolioSlider() {
  return (
    <div className='container'>
        PortfolioSlider
        <Card/>
    </div>
  )
}

export default PortfolioSlider